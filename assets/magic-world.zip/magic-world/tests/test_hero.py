import unittest
import os
from hero import Hero
__unittest = True

CWD = os.getcwd()


class TestHero(unittest.TestCase):
    def test_name(self):
        player = Hero()
        msg = "У героя должно быть имя!"

        self.assertTrue(hasattr(player, 'name'), msg)
        self.assertGreater(len(player.name), 0)


    def test_greetings(self):
        player = Hero()
        msg = "Герой должен уметь здороваться!"

        self.assertTrue(hasattr(player, 'say_hello'), msg)
        self.assertIsInstance(
                player.say_hello(),
                str,
                "greetings should return a string!"
            )

    def test_find_your_way(self):
        result = os.path.join(CWD)

        hero = Hero()
        err_msg = "У героя должен быть атрибут find_your_way()"
        self.assertTrue(hasattr(hero, "find_your_way"), err_msg)

        err_msg = "Герой должен уметь находить дорогу"

        self.assertEqual(hero.find_your_way(CWD), result, err_msg)

    def test_go_to(self):
        dest = os.path.join(CWD)
        result = os.listdir(dest)

        err_msg = 'У героя должен быть атрибут go_to()'

        hero = Hero()

        self.assertTrue(hasattr(hero, 'go_to'), err_msg)

        err_msg = 'Метод должен возврожать список строк'
        self.assertIsInstance(hero.go_to(dest), list, err_msg)
        err_msg = 'Герой должен уметь пройти в нужном направлении'
        self.assertListEqual(result, hero.go_to(dest), err_msg)


if __name__ == '__main__':
    unittest.main()
