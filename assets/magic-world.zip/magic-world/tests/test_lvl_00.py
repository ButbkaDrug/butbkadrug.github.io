import unittest
import os
from lvl_00 import main

class testLevel(unittest.TestCase):
    def test_return_type(self):
        self.assertIsInstance(
                main(),
                list,
                'Функция должна вернуть список строк'
        )


    def test_return_value(self):
        path = os.path.join(os.getcwd(), 'castle', 'second_floor', 'library')

        self.assertListEqual(
                os.listdir(path),
                main(),
                'Похоже, что наши списки не совпадают. Убедись что ты возвращаешь список фалов в библиотеке'
        )
