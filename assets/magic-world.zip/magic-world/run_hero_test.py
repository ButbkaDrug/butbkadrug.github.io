import unittest
from tests.test_hero import TestHero

if __name__ == '__main__':
    unittest.main()
