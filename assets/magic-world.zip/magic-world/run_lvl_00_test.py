import unittest
from tests.test_lvl_00 import testLevel

if __name__ == '__main__':
    unittest.main()
